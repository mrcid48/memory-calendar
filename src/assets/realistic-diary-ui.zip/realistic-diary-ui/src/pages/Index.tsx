import { DiaryBook } from "@/components/diary/DiaryBook";
import deskTexture from "@/assets/desk-texture.jpg";

const Index = () => {
  return (
    <main 
      className="min-h-screen flex flex-col items-center justify-center py-6 sm:py-8 md:py-12 px-2 sm:px-4 relative overflow-hidden"
      style={{
        backgroundImage: `url(${deskTexture})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed",
      }}
    >
      {/* Dark overlay for readability */}
      <div 
        className="fixed inset-0 pointer-events-none"
        style={{
          background: "hsla(25, 30%, 8%, 0.4)",
        }}
      />

      {/* Ambient lighting effect */}
      <div 
        className="fixed inset-0 pointer-events-none"
        style={{
          background: `
            radial-gradient(ellipse at 50% 30%, hsla(40, 60%, 50%, 0.12) 0%, transparent 50%),
            radial-gradient(ellipse at 80% 80%, hsla(25, 50%, 30%, 0.08) 0%, transparent 40%),
            radial-gradient(ellipse at 20% 70%, hsla(30, 40%, 25%, 0.08) 0%, transparent 40%)
          `,
        }}
      />

      {/* Vignette effect */}
      <div 
        className="fixed inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse at center, transparent 40%, hsla(20, 30%, 5%, 0.6) 100%)",
        }}
      />

      {/* Header */}
      <header className="relative z-10 text-center mb-4 sm:mb-8 md:mb-12 animate-fade-in px-4">
        <h1 
          className="font-script text-3xl sm:text-4xl md:text-5xl lg:text-6xl mb-1 sm:mb-2 drop-shadow-lg"
          style={{
            background: "linear-gradient(145deg, hsl(42, 85%, 65%) 0%, hsl(38, 70%, 50%) 50%, hsl(42, 80%, 65%) 100%)",
            WebkitBackgroundClip: "text",
            backgroundClip: "text",
            color: "transparent",
            filter: "drop-shadow(0 2px 10px hsla(40, 80%, 40%, 0.4))",
          }}
        >
          Personal Journal
        </h1>
        <p 
          className="font-serif italic text-sm sm:text-base md:text-lg"
          style={{ color: "hsla(40, 30%, 80%, 0.8)" }}
        >
          Where thoughts become timeless
        </p>
        <div 
          className="mt-2 sm:mt-3 md:mt-4 mx-auto w-24 sm:w-36 md:w-48 h-px"
          style={{
            background: "linear-gradient(90deg, transparent, hsl(40, 60%, 55%, 0.5), transparent)",
          }}
        />
      </header>

      {/* Diary component */}
      <section className="relative z-10 w-full max-w-3xl">
        <DiaryBook />
      </section>

      {/* Bottom gradient fade */}
      <div 
        className="fixed bottom-0 left-0 right-0 h-20 sm:h-32 md:h-40 pointer-events-none"
        style={{
          background: "linear-gradient(to top, hsla(20, 30%, 5%, 0.8), transparent)",
        }}
      />
    </main>
  );
};

export default Index;
