import { useCallback, useRef } from "react";

// Page flip sound using Web Audio API - creates a realistic paper rustling effect
export const usePageFlipSound = () => {
  const audioContextRef = useRef<AudioContext | null>(null);

  const getAudioContext = useCallback(() => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    return audioContextRef.current;
  }, []);

  const playPageFlipSound = useCallback(() => {
    try {
      const audioContext = getAudioContext();
      
      // Resume context if suspended (required for autoplay policies)
      if (audioContext.state === "suspended") {
        audioContext.resume();
      }

      const currentTime = audioContext.currentTime;

      // Create noise buffer for paper rustling effect
      const bufferSize = audioContext.sampleRate * 0.3; // 300ms sound
      const noiseBuffer = audioContext.createBuffer(1, bufferSize, audioContext.sampleRate);
      const output = noiseBuffer.getChannelData(0);

      // Generate filtered noise that sounds like paper
      for (let i = 0; i < bufferSize; i++) {
        output[i] = (Math.random() * 2 - 1) * 0.5;
      }

      // Create noise source
      const noiseSource = audioContext.createBufferSource();
      noiseSource.buffer = noiseBuffer;

      // Bandpass filter to make it sound like paper
      const bandpass = audioContext.createBiquadFilter();
      bandpass.type = "bandpass";
      bandpass.frequency.value = 2000;
      bandpass.Q.value = 0.5;

      // High-pass filter for crisp paper sound
      const highpass = audioContext.createBiquadFilter();
      highpass.type = "highpass";
      highpass.frequency.value = 400;

      // Create envelope for the sound
      const gainNode = audioContext.createGain();
      gainNode.gain.setValueAtTime(0, currentTime);
      gainNode.gain.linearRampToValueAtTime(0.15, currentTime + 0.02);
      gainNode.gain.linearRampToValueAtTime(0.08, currentTime + 0.1);
      gainNode.gain.linearRampToValueAtTime(0.12, currentTime + 0.15);
      gainNode.gain.exponentialRampToValueAtTime(0.001, currentTime + 0.3);

      // Add a subtle whoosh using oscillator
      const oscillator = audioContext.createOscillator();
      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(150, currentTime);
      oscillator.frequency.exponentialRampToValueAtTime(80, currentTime + 0.2);

      const oscGain = audioContext.createGain();
      oscGain.gain.setValueAtTime(0, currentTime);
      oscGain.gain.linearRampToValueAtTime(0.03, currentTime + 0.05);
      oscGain.gain.exponentialRampToValueAtTime(0.001, currentTime + 0.25);

      // Connect noise chain
      noiseSource.connect(bandpass);
      bandpass.connect(highpass);
      highpass.connect(gainNode);
      gainNode.connect(audioContext.destination);

      // Connect oscillator chain
      oscillator.connect(oscGain);
      oscGain.connect(audioContext.destination);

      // Play sounds
      noiseSource.start(currentTime);
      noiseSource.stop(currentTime + 0.3);
      oscillator.start(currentTime);
      oscillator.stop(currentTime + 0.25);

    } catch (error) {
      console.log("Audio playback not available:", error);
    }
  }, [getAudioContext]);

  return { playPageFlipSound };
};
