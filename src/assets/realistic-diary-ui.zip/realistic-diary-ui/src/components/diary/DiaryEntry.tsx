import React from "react";

interface DiaryEntryProps {
  date: string;
  title?: string;
  content: string;
  mood?: "happy" | "sad" | "thoughtful" | "excited" | "peaceful";
}

export const DiaryEntry: React.FC<DiaryEntryProps> = ({
  date,
  title,
  content,
  mood = "peaceful",
}) => {
  const moodEmojis = {
    happy: "☀️",
    sad: "🌧️",
    thoughtful: "🌙",
    excited: "⭐",
    peaceful: "🍃",
  };

  return (
    <article className="h-full flex flex-col">
      {/* Date header */}
      <header className="mb-2 sm:mb-4 md:mb-6">
        <div className="flex items-center justify-between mb-1 sm:mb-2">
          <time className="text-ink-faded font-serif text-[10px] sm:text-xs md:text-sm italic tracking-wide">
            {date}
          </time>
          <span className="text-sm sm:text-base md:text-xl" title={mood}>
            {moodEmojis[mood]}
          </span>
        </div>
        {title && (
          <h2 className="handwriting-title text-lg sm:text-2xl md:text-3xl text-ink leading-tight">
            {title}
          </h2>
        )}
        <div 
          className="mt-1 sm:mt-2 md:mt-3 h-px w-16 sm:w-20 md:w-24 opacity-30"
          style={{ background: "linear-gradient(90deg, hsl(25, 60%, 30%), transparent)" }}
        />
      </header>

      {/* Entry content */}
      <div className="flex-1 overflow-hidden">
        <p className="handwriting text-sm sm:text-lg md:text-xl lg:text-2xl leading-[20px] sm:leading-[24px] md:leading-[28px] lg:leading-[32px] text-ink whitespace-pre-wrap">
          {content}
        </p>
      </div>
    </article>
  );
};
