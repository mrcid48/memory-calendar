import React, { useRef, useState, useCallback, useEffect } from "react";
import HTMLFlipBook from "react-pageflip";
import { DiaryPage } from "./DiaryPage";
import { DiaryEntry } from "./DiaryEntry";
import { DiaryCover } from "./DiaryCover";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { usePageFlipSound } from "@/hooks/usePageFlipSound";
interface Entry {
  date: string;
  title?: string;
  content: string;
  mood?: "happy" | "sad" | "thoughtful" | "excited" | "peaceful";
}

const sampleEntries: Entry[] = [
  {
    date: "December 15, 2024",
    title: "A New Beginning",
    content: `Today marks the start of something beautiful. I've decided to keep this diary as a sanctuary for my thoughts, dreams, and memories.

The winter sun cast long shadows across my desk as I wrote these first words.

I hope these pages will one day tell a story worth remembering.`,
    mood: "excited",
  },
  {
    date: "December 16, 2024",
    title: "Morning Reflections",
    content: `Woke up to the sound of rain against my window. There's a certain peace in rainy mornings that I've come to cherish.

Made myself a cup of tea and watched the droplets race down the glass.

Sometimes the most profound moments come in the quietest hours.`,
    mood: "peaceful",
  },
  {
    date: "December 17, 2024",
    title: "Unexpected Joy",
    content: `A letter arrived today from an old friend. We hadn't spoken in years, yet reading their words felt like no time had passed at all.

Some friendships are woven from sturdier thread than others.

I've decided to write back tonight, by candlelight.`,
    mood: "happy",
  },
  {
    date: "December 18, 2024",
    title: "Evening Thoughts",
    content: `The stars seem brighter in winter. Perhaps it's the cold, crisp air, or maybe it's just that we look up more often.

I've been thinking about the year that's passed.

Tomorrow is never promised, but tonight, I am grateful.`,
    mood: "thoughtful",
  },
  {
    date: "December 19, 2024",
    title: "Today's Adventures",
    content: `Ventured out to the old bookshop on the corner. Found a leather-bound volume of poetry from 1892.

The shopkeeper smiled knowingly as I held it. "Some books find their owners," she said.

I think I understand what she meant now.`,
    mood: "excited",
  },
  {
    date: "December 20, 2024",
    content: `Sometimes words are not enough. Today was one of those days where emotions run deeper than language can reach.

I sat by the window and simply watched the world go by.

And somehow, in the silence, I found peace.`,
    mood: "peaceful",
  },
];

export const DiaryBook: React.FC = () => {
  const bookRef = useRef<any>(null);
  const [currentPage, setCurrentPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [dimensions, setDimensions] = useState({ width: 400, height: 550 });
  const { playPageFlipSound } = usePageFlipSound();

  // Calculate responsive dimensions for two-page book view
  useEffect(() => {
    const updateDimensions = () => {
      const screenWidth = window.innerWidth;
      const screenHeight = window.innerHeight;
      
      let width: number;
      let height: number;
      
      if (screenWidth < 480) {
        // Mobile portrait - smaller size
        width = Math.min(screenWidth - 32, 240);
        height = Math.min(screenHeight - 280, width * 0.7);
      } else if (screenWidth < 768) {
        // Mobile landscape / small tablet
        width = Math.min(screenWidth - 48, 450);
        height = Math.min(screenHeight - 220, width * 0.5);
      } else if (screenWidth < 1024) {
        // Tablet - two pages side by side, smaller
        width = Math.min(screenWidth - 80, 600);
        height = width * 0.5;
      } else {
        // Desktop - two pages, smaller size
        width = 700;
        height = 420;
      }
      
      setDimensions({ width, height });
    };

    updateDimensions();
    window.addEventListener("resize", updateDimensions);
    return () => window.removeEventListener("resize", updateDimensions);
  }, []);

  const onFlip = useCallback((e: { data: number }) => {
    setCurrentPage(e.data);
    playPageFlipSound();
  }, [playPageFlipSound]);

  const onInit = useCallback((e: { data: { pages: number } }) => {
    setTotalPages(e.data.pages);
  }, []);

  const flipPrev = () => {
    bookRef.current?.pageFlip()?.flipPrev();
  };

  const flipNext = () => {
    bookRef.current?.pageFlip()?.flipNext();
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center w-full px-2 sm:px-4 py-8">
      {/* Book shadow */}
      <div 
        className="absolute -bottom-4 sm:-bottom-8 left-1/2 -translate-x-1/2 w-[75%] sm:w-[70%] h-4 sm:h-8 rounded-[50%] blur-xl opacity-40"
        style={{ background: "hsl(25, 50%, 10%)" }}
      />

      {/* Flipbook container */}
      <div className="relative">
        {/* Spine effect - hidden on very small screens */}
        <div 
          className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-4 sm:w-6 md:w-8 z-20 pointer-events-none book-spine hidden sm:block"
          style={{
            background: `linear-gradient(90deg, 
              hsl(12, 60%, 10%) 0%,
              hsl(15, 55%, 18%) 30%,
              hsl(20, 50%, 25%) 50%,
              hsl(15, 55%, 18%) 70%,
              hsl(12, 60%, 10%) 100%
            )`,
          }}
        />
        
        {/* @ts-ignore - react-pageflip types are incomplete */}
        <HTMLFlipBook
          key={`${dimensions.width}-${dimensions.height}`}
          ref={bookRef}
          width={dimensions.width}
          height={dimensions.height}
          size="fixed"
          minWidth={300}
          maxWidth={1200}
          minHeight={200}
          maxHeight={700}
          drawShadow={true}
          flippingTime={600}
          usePortrait={false}
          startZIndex={0}
          autoSize={false}
          maxShadowOpacity={0.4}
          showCover={true}
          mobileScrollSupport={true}
          onFlip={onFlip}
          onInit={onInit}
          className="shadow-book"
          style={{}}
          startPage={0}
          clickEventForward={true}
          useMouseEvents={true}
          swipeDistance={20}
          showPageCorners={true}
          disableFlipByClick={false}
        >
          {/* Front Cover */}
          <div className="page-wrapper">
            <DiaryCover type="front" />
          </div>

          {/* Inside front cover - blank page */}
          <div className="page-wrapper">
            <DiaryPage className="bg-leather-dark" pageNumber={undefined}>
              <div className="h-full flex items-center justify-center">
                <p className="handwriting-title text-2xl sm:text-3xl md:text-4xl text-gold opacity-70 text-center px-4">
                  My Personal Diary
                </p>
              </div>
            </DiaryPage>
          </div>

          {/* Diary entries */}
          {sampleEntries.map((entry, index) => (
            <div key={index} className="page-wrapper">
              <DiaryPage pageNumber={index + 1}>
                <DiaryEntry {...entry} />
              </DiaryPage>
            </div>
          ))}

          {/* Empty pages for writing */}
          <div className="page-wrapper">
            <DiaryPage pageNumber={sampleEntries.length + 1}>
              <div className="h-full flex flex-col">
                <p className="handwriting text-lg sm:text-xl md:text-2xl text-ink-faded italic opacity-50">
                  Continue your story here...
                </p>
              </div>
            </DiaryPage>
          </div>

          <div className="page-wrapper">
            <DiaryPage pageNumber={sampleEntries.length + 2}>
              <div className="h-full" />
            </DiaryPage>
          </div>

          {/* Back Cover */}
          <div className="page-wrapper">
            <DiaryCover type="back" />
          </div>
        </HTMLFlipBook>
      </div>

      {/* Navigation controls */}
      <div className="mt-4 sm:mt-6 md:mt-8 flex items-center gap-2 sm:gap-4 md:gap-6">
        <button
          onClick={flipPrev}
          disabled={currentPage === 0}
          className="group flex items-center gap-1 sm:gap-2 px-2 sm:px-3 md:px-4 py-1.5 sm:py-2 rounded-full transition-all duration-300 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-gold/10 active:scale-95"
          aria-label="Previous page"
        >
          <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5 text-gold group-hover:scale-110 transition-transform" />
          <span className="font-serif text-xs sm:text-sm text-foreground/80 hidden xs:inline">Previous</span>
        </button>

        <div className="flex items-center gap-1 sm:gap-2">
          <span className="font-handwriting text-lg sm:text-xl text-gold">
            {currentPage + 1}
          </span>
          <span className="text-foreground/50 font-serif text-xs sm:text-sm">/</span>
          <span className="font-serif text-xs sm:text-sm text-foreground/50">
            {totalPages}
          </span>
        </div>

        <button
          onClick={flipNext}
          disabled={currentPage >= totalPages - 1}
          className="group flex items-center gap-1 sm:gap-2 px-2 sm:px-3 md:px-4 py-1.5 sm:py-2 rounded-full transition-all duration-300 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-gold/10 active:scale-95"
          aria-label="Next page"
        >
          <span className="font-serif text-xs sm:text-sm text-foreground/80 hidden xs:inline">Next</span>
          <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5 text-gold group-hover:scale-110 transition-transform" />
        </button>
      </div>

      {/* Hint text */}
      <p className="mt-2 sm:mt-4 font-serif text-[10px] sm:text-xs text-foreground/40 italic text-center px-4">
        Swipe or tap page corners to flip
      </p>
    </div>
  );
};
