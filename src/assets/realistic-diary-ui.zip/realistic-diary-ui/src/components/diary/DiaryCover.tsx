import React, { forwardRef } from "react";
import leatherTexture from "@/assets/leather-texture.jpg";

interface DiaryCoverProps {
  type: "front" | "back";
}

export const DiaryCover = forwardRef<HTMLDivElement, DiaryCoverProps>(
  ({ type }, ref) => {
    return (
      <div
        ref={ref}
        className="relative w-full h-full rounded-r-sm overflow-hidden"
        style={{
          backgroundImage: `url(${leatherTexture})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        {/* Leather overlay for depth */}
        <div 
          className="absolute inset-0"
          style={{
            background: `linear-gradient(
              145deg,
              hsla(20, 50%, 30%, 0.3) 0%,
              hsla(15, 55%, 20%, 0.5) 50%,
              hsla(12, 60%, 12%, 0.7) 100%
            )`,
          }}
        />

        {/* Edge stitching effect */}
        <div 
          className="absolute inset-1 sm:inset-2 border sm:border-2 rounded-sm pointer-events-none"
          style={{
            borderColor: "hsla(40, 60%, 50%, 0.3)",
            borderStyle: "dashed",
          }}
        />

        {type === "front" && (
          <>
            {/* Gold corner embellishments - smaller on mobile */}
            <div className="absolute top-2 sm:top-4 left-2 sm:left-4 w-6 sm:w-8 md:w-12 h-6 sm:h-8 md:h-12">
              <svg viewBox="0 0 48 48" className="w-full h-full opacity-60">
                <path
                  d="M0 0 L20 0 L20 4 L4 4 L4 20 L0 20 Z"
                  fill="url(#goldGradient)"
                />
                <defs>
                  <linearGradient id="goldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="hsl(42, 85%, 55%)" />
                    <stop offset="50%" stopColor="hsl(38, 70%, 40%)" />
                    <stop offset="100%" stopColor="hsl(42, 85%, 55%)" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
            <div className="absolute top-2 sm:top-4 right-2 sm:right-4 w-6 sm:w-8 md:w-12 h-6 sm:h-8 md:h-12 rotate-90">
              <svg viewBox="0 0 48 48" className="w-full h-full opacity-60">
                <path
                  d="M0 0 L20 0 L20 4 L4 4 L4 20 L0 20 Z"
                  fill="url(#goldGradient)"
                />
              </svg>
            </div>
            <div className="absolute bottom-2 sm:bottom-4 left-2 sm:left-4 w-6 sm:w-8 md:w-12 h-6 sm:h-8 md:h-12 -rotate-90">
              <svg viewBox="0 0 48 48" className="w-full h-full opacity-60">
                <path
                  d="M0 0 L20 0 L20 4 L4 4 L4 20 L0 20 Z"
                  fill="url(#goldGradient)"
                />
              </svg>
            </div>
            <div className="absolute bottom-2 sm:bottom-4 right-2 sm:right-4 w-6 sm:w-8 md:w-12 h-6 sm:h-8 md:h-12 rotate-180">
              <svg viewBox="0 0 48 48" className="w-full h-full opacity-60">
                <path
                  d="M0 0 L20 0 L20 4 L4 4 L4 20 L0 20 Z"
                  fill="url(#goldGradient)"
                />
              </svg>
            </div>

            {/* Title */}
            <div className="absolute inset-0 flex flex-col items-center justify-center px-4">
              <div 
                className="px-4 sm:px-6 md:px-8 py-2 sm:py-3 md:py-4 rounded-sm"
                style={{
                  background: "linear-gradient(145deg, hsla(42, 85%, 55%, 0.15), hsla(38, 70%, 40%, 0.1))",
                  border: "1px solid hsla(40, 70%, 50%, 0.3)",
                }}
              >
                <h1 
                  className="font-script text-2xl sm:text-3xl md:text-4xl lg:text-5xl text-center leading-tight"
                  style={{
                    background: "linear-gradient(145deg, hsl(42, 85%, 55%) 0%, hsl(38, 70%, 40%) 50%, hsl(42, 85%, 55%) 100%)",
                    WebkitBackgroundClip: "text",
                    backgroundClip: "text",
                    color: "transparent",
                    textShadow: "0 2px 4px hsla(40, 80%, 30%, 0.3)",
                  }}
                >
                  My Diary
                </h1>
              </div>

              {/* Decorative line */}
              <div 
                className="mt-2 sm:mt-3 md:mt-4 w-16 sm:w-24 md:w-32 h-px"
                style={{
                  background: "linear-gradient(90deg, transparent, hsl(42, 75%, 50%), transparent)",
                }}
              />

              {/* Year */}
              <p 
                className="mt-2 sm:mt-3 md:mt-4 font-serif text-xs sm:text-sm md:text-lg tracking-[0.2em] sm:tracking-[0.3em]"
                style={{
                  color: "hsla(40, 60%, 60%, 0.8)",
                }}
              >
                2024
              </p>
            </div>

            {/* Ribbon bookmark sticking out */}
            <div 
              className="absolute -top-1 sm:-top-2 right-8 sm:right-12 md:right-16"
              style={{
                width: "12px",
                height: "40px",
                background: "linear-gradient(180deg, hsl(0, 70%, 40%) 0%, hsl(0, 65%, 30%) 100%)",
                clipPath: "polygon(0 0, 100% 0, 100% 90%, 50% 100%, 0 90%)",
                boxShadow: "2px 2px 8px hsla(0, 0%, 0%, 0.3)",
              }}
            />
          </>
        )}

        {type === "back" && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div 
              className="w-10 sm:w-12 md:w-16 h-10 sm:h-12 md:h-16 rounded-full flex items-center justify-center"
              style={{
                background: "linear-gradient(145deg, hsla(42, 85%, 55%, 0.2), hsla(38, 70%, 40%, 0.1))",
                border: "1px solid hsla(40, 70%, 50%, 0.2)",
              }}
            >
              <span 
                className="font-script text-lg sm:text-xl md:text-2xl"
                style={{
                  color: "hsla(40, 70%, 55%, 0.7)",
                }}
              >
                D
              </span>
            </div>
          </div>
        )}

        {/* Worn edges effect */}
        <div 
          className="absolute inset-0 pointer-events-none"
          style={{
            boxShadow: "inset 0 0 30px 10px hsla(25, 60%, 10%, 0.4)",
          }}
        />
      </div>
    );
  }
);

DiaryCover.displayName = "DiaryCover";
