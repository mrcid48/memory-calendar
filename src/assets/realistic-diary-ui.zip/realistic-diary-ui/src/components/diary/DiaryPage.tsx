import React, { forwardRef } from "react";
import paperTexture from "@/assets/paper-texture.jpg";

interface DiaryPageProps {
  children: React.ReactNode;
  pageNumber?: number;
  className?: string;
}

export const DiaryPage = forwardRef<HTMLDivElement, DiaryPageProps>(
  ({ children, pageNumber, className = "" }, ref) => {
    return (
      <div
        ref={ref}
        className={`diary-page relative w-full h-full p-3 sm:p-5 md:p-8 ${className}`}
        style={{
          backgroundImage: `url(${paperTexture})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        {/* Line overlay */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="w-full h-full" style={{
            backgroundImage: `repeating-linear-gradient(
              transparent,
              transparent 23px,
              rgba(139, 90, 43, 0.12) 23px,
              rgba(139, 90, 43, 0.12) 24px
            )`,
            backgroundPosition: "0 18px"
          }} />
        </div>
        
        {/* Red margin line */}
        <div 
          className="absolute top-0 bottom-0 left-8 sm:left-12 md:left-16 w-px opacity-40"
          style={{ background: "hsl(0, 60%, 50%)" }}
        />
        
        {/* Content area */}
        <div className="relative z-10 h-full pl-4 sm:pl-6 md:pl-8">
          {children}
        </div>
        
        {/* Page number */}
        {pageNumber !== undefined && (
          <div className="absolute bottom-2 sm:bottom-3 md:bottom-4 left-1/2 -translate-x-1/2">
            <span className="page-number text-xs sm:text-sm md:text-lg italic opacity-60">
              {pageNumber}
            </span>
          </div>
        )}
        
        {/* Random coffee stain for aged effect - hidden on mobile */}
        {pageNumber && pageNumber % 3 === 0 && (
          <div 
            className="coffee-stain hidden sm:block"
            style={{
              width: "80px",
              height: "70px",
              top: "15%",
              right: "10%",
            }}
          />
        )}
      </div>
    );
  }
);

DiaryPage.displayName = "DiaryPage";
